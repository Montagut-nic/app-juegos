export const environment = {
  production: true,
  supabaseUrl: 'https://oulpgsltvlibsjrrinco.supabase.co',
  supabaseAnonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im91bHBnc2x0dmxpYnNqcnJpbmNvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY1NDE1NjAsImV4cCI6MjA3MjExNzU2MH0.WKdQV7Ayy1xAH6xn7eUYVbJFgCimk81aRXFkbP1g7b0'
};


// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
export const firebaseConfig = {
  apiKey: "AIzaSyApddHC7sfhHAZ2vTEmhE4HnuPBtjmJ7vU",
  authDomain: "casino-angular-juegos.firebaseapp.com",
  projectId: "casino-angular-juegos",
  storageBucket: "casino-angular-juegos.firebasestorage.app",
  messagingSenderId: "1082385074644",
  appId: "1:1082385074644:web:a50854b64d4181348a2e41"
};

// Initialize Firebase
