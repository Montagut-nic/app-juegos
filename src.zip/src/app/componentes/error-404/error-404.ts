import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-error-404',
  imports: [],
  templateUrl: './error-404.html',
  styleUrl: './error-404.scss'
})
export class Error404 {

}
