import { Component } from '@angular/core';

@Component({
  selector: 'app-trivia',
  imports: [],
  templateUrl: './trivia.component.html',
  styleUrl: './trivia.component.scss'
})
export class TriviaComponent {

}
