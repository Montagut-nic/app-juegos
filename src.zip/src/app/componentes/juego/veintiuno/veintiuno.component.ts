import { Component } from '@angular/core';

@Component({
  selector: 'app-veintiuno',
  imports: [],
  templateUrl: './veintiuno.component.html',
  styleUrl: './veintiuno.component.scss'
})
export class VeintiunoComponent {

}
