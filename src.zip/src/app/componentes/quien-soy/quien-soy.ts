import { Component } from '@angular/core';

@Component({
  standalone: true,
  selector: 'app-quien-soy',
  imports: [],
  templateUrl: './quien-soy.html',
  styleUrl: './quien-soy.scss'
})
export class QuienSoy {

}
